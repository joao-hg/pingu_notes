import '../entities/note.dart';
import '../repositories/note_repository.dart';

class AddNote {
  final NoteRepository repository;

  AddNote(this.repository);

  Future<Note> call(Note note) async {
    return await repository.addNote(note);
  }
}
